# IfState

Manage host interface settings in a declarative manner relying only on *iproute2*. [More...](https://liske.github.io/ifstate/)
