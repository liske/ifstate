class LinkCannotAdd(Exception):
    pass

class LinkTypeUnknown(Exception):
    pass

class LinkDuplicate(Exception):
    pass

class LinkCircularLinked(Exception):
    pass

class LinkNoConfigFound(Exception):
    pass

class RouteDupblicate(Exception):
    pass
