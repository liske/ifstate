import libifstate.link.base
import libifstate.link.physical
import libifstate.link.tun
import libifstate.link.veth
